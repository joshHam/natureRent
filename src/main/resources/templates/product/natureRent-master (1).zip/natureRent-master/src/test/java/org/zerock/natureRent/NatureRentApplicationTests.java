package org.zerock.natureRent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NatureRentApplicationTests {

	@Test
	void contextLoads() {
	}

}
