package org.zerock.natureRent.entity;

public enum ClubMemberRole {

    USER,MANAGER,ADMIN,OAUTH2_USER,

}
